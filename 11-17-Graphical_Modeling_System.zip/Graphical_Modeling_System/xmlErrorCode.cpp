#include "xmlErrorCode.h"

int XMLErrorCode::OK = 0;
int XMLErrorCode::Save_PathError = 1;
int XMLErrorCode::Open_NotExist = 2;
int XMLErrorCode::IOError = 3;
