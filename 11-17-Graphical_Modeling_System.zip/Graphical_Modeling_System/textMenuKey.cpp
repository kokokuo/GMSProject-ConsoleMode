#include "textMenuKey.h"

int TextMenuKey::HomeMenuKey = 0;
int TextMenuKey::GMSMenuKey = 1;
int TextMenuKey::GroupMenuKey = 2;
int TextMenuKey::AddComponentMenuKey = 3;
